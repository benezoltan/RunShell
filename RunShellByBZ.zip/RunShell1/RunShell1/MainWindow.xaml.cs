﻿using System.Diagnostics;
using System.IO;
//using System.IO.Path;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RunShell1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Projekt mappájának elérési útja
                string projectDir = Directory.GetCurrentDirectory();

                // Script relatív útvonala a projekt mappán belül
                string scriptPath = System.IO.Path.Combine(projectDir, "script.ps1");

                if (!File.Exists(scriptPath))
                {
                    System.Diagnostics.Debug.WriteLine("A PowerShell script nem található: " + scriptPath);
                    return;
                }

                // PowerShell elérési útja
                string psPath = @"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe";

                // Process beállítása
                ProcessStartInfo startInfo = new ProcessStartInfo()
                {
                    FileName = psPath,
                    Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string errors = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    System.Diagnostics.Debug.WriteLine("=== PowerShell output ===");
                    System.Diagnostics.Debug.WriteLine(output);
                    textbox1.AppendText(output);

                    if (!string.IsNullOrEmpty(errors))
                    {
                        System.Diagnostics.Debug.WriteLine("=== PowerShell errors ===");
                        System.Diagnostics.Debug.WriteLine(errors);
                        textbox1.AppendText(errors);

                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Hiba a PowerShell script futtatása közben: " + ex.Message);
                textbox1.AppendText("Hiba a PowerShell script futtatása közben: " + ex.Message);

            }
        }

        private void textbox1_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            {
                string psPath = @"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe";

                // Ide írd a PowerShell parancsot
                String command = commandBox.Text;
                if(command=="")
                command = "Get-Process | Select-Object -First 5";

                ProcessStartInfo startInfo = new ProcessStartInfo()
                {
                    FileName = psPath,
                    Arguments = $"-NoProfile -ExecutionPolicy Bypass -Command \"{command}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    string output = process.StandardOutput.ReadToEnd();
                    string errors = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    textbox1.AppendText("Output:");
                    textbox1.AppendText(output);

                    if (!string.IsNullOrEmpty(errors))
                    {
                        Console.WriteLine("Errors:");
                        Console.WriteLine(errors);
                        textbox1.AppendText(errors);
                    }
                }
            }
        }
    }
}
